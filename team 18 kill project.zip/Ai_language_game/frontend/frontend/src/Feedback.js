import React, { useEffect } from 'react';
import './FeedbackPopup.css'; // We will create this next!

const FeedbackPopup = ({ isVisible, isCorrect, onClose }) => {
  const positiveMessages = ["Excellent!", "Marvelous!", "Fantastic!", "Brilliant!"];
  const negativeMessages = ["Try Again!", "Almost there!", "Don't give up!", "Keep practicing!"];

  // Select a random message
  const message = isCorrect 
    ? positiveMessages[Math.floor(Math.random() * positiveMessages.length)]
    : negativeMessages[Math.floor(Math.random() * negativeMessages.length)];

  useEffect(() => {
    if (isVisible) {
      const timer = setTimeout(() => {
        onClose();
      }, 2000); // Popup stays for 2 seconds
      return () => clearTimeout(timer);
    }
  }, [isVisible, onClose]);

  if (!isVisible) return null;

  return (
    <div className={`feedback-overlay ${isCorrect ? 'success' : 'error'}`}>
      <div className="feedback-content">
        <h1>{message}</h1>
        <div className="feedback-icon">{isCorrect ? '🌟' : '💡'}</div>
      </div>
    </div>
  );
};

export default FeedbackPopup;