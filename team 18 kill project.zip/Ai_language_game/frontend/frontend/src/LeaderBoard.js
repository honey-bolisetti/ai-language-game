import React from 'react';

const Leaderboard = ({ players }) => {
  return (
    <div className="leaderboard-container">
      <h2>🏆 Top 30 Language Legends</h2>
      <table className="leaderboard-table">
        <thead>
          <tr>
            <th>Rank</th>
            <th>Player</th>
            <th>Score</th>
          </tr>
        </thead>
        <tbody>
          {players.slice(0, 30).map((player, index) => (
            <tr key={index} className={index < 3 ? 'top-three' : ''}>
              <td>{index + 1}</td>
              <td>{player.username}</td>
              <td>{player.score}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
};

export default Leaderboard;