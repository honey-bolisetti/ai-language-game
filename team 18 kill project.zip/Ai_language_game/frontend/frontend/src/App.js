import React, { useState, useEffect } from 'react';
import './App.css';
import FeedbackPopup from './FeedbackPopup';

function App() {
  // --- 1. STATE DECLARATIONS ---
  const [currentWord, setCurrentWord] = useState(null);
  const [userInput, setUserInput] = useState('');
  const [feedbackType, setFeedbackType] = useState(null);
  const [topPlayers, setTopPlayers] = useState([]);
  const [sessionScore, setSessionScore] = useState(0); 
  const [attempts, setAttempts] = useState(0); // For Hints
  const [selectedLang, setSelectedLang] = useState('bodo'); // Default language

  // --- 2. API FETCH FUNCTIONS ---
const fetchLeaderboard = () => {
    fetch('http://localhost:5000/api/leaderboard')
      .then(res => res.json())
      .then(data => setTopPlayers(data))
      .catch(err => console.error("Error fetching leaderboard:", err));
  };

  const fetchNewWord = (lang = selectedLang) => {
    fetch(`http://localhost:5000/api/random-word?lang=${lang}`) 
      .then(res => res.json())
      .then(data => {
        if (data) setCurrentWord(data);
      })
      .catch(err => console.error("Error fetching word:", err));
  };

  // --- 3. THE INITIAL LOAD ---
  useEffect(() => {
    fetchNewWord(selectedLang); 
    fetchLeaderboard(); // Now this function is defined and ready to be called
  }, [selectedLang]);

  // --- 3. GAME LOGIC ---
  const checkAnswer = async () => {
    if (!currentWord) return;

    const isCorrect = userInput.toLowerCase().trim() === currentWord.translation.toLowerCase().trim();

    if (isCorrect) {
      setFeedbackType('success');
      setSessionScore(prev => prev + 10);
      
      await fetch('http://localhost:5000/api/save-score', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ 
          username: "Harshita Bolisetti", 
          score: 10 
        })
      });
      
      fetchLeaderboard();
      setAttempts(0); // Reset hints for next word

      setTimeout(() => {
        setFeedbackType(null);
        setUserInput('');
        fetchNewWord();
      }, 2000);

    } else {
      setFeedbackType('error');
      setAttempts(prev => prev + 1); // Trigger hint after first fail
      
      setTimeout(() => {
        setFeedbackType(null);
      }, 2000);
    }
  };

  const handleSkip = () => {
    setAttempts(0);
    setUserInput('');
    fetchNewWord();
  };

  // --- 4. RENDER UI ---
  return (
    <div className="App">
      {feedbackType && (
        <div className={`feedback-overlay ${feedbackType}`}>
          <h1>{feedbackType === 'success' ? 'Excellent! 🌟' : 'Try Again! 💡'}</h1>
        </div>
      )}

      <header className="App-header">
        <div className="score-badge">Your Score: {sessionScore}</div>

        {currentWord ? (
          <>
            <h2>Translate to English: {currentWord.phrase}</h2>
            
            {/* HINT DISPLAY */}
            {attempts > 0 && (
              <p className="hint-text">
                Hint: Starts with "<strong>{currentWord.translation[0]}</strong>"
              </p>
            )}

            <input 
              value={userInput} 
              onChange={(e) => setUserInput(e.target.value)}
              placeholder="Type answer here..."
            />
            
            <div className="button-group">
                <button onClick={checkAnswer}>Submit</button>
                <button className="skip-btn" onClick={handleSkip}>Skip</button>
            </div>
          </>
        ) : (
          <p>Loading your language quest...</p>
        )}

        <div className="leaderboard-session">
          <h3>🏆 Top 30 Legends</h3>
          {topPlayers.map((p, i) => (
            <div key={i} className="leaderboard-row">
              <span>{i + 1}. {p.username}</span>
              <span>{p.score} pts</span>
            </div>
          ))}
        </div>
      </header>
    </div>
  );
}

export default App;