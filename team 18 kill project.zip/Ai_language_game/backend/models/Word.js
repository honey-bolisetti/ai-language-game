const mongoose = require('mongoose');
const wordSchema = new mongoose.Schema({
  languageCode: String,
  phrase: String,
  translation: String,
  type: String,
  difficulty: Number // Ensure this is Number, not String!
});
// This 'Word' here creates a collection named 'words' in the DB
module.exports = mongoose.model('Word', wordSchema);