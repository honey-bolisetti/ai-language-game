const mongoose = require('mongoose');
const Word = require('./models/Word'); 
require('dotenv').config();

const words = [
  // --- BODO (BRX) ---
  { phrase: "Kulumby", translation: "Hello", languageCode: "brx", type: "match", difficulty: 1 },
  { phrase: "Kulumby", translation: "Hello", languageCode: "brx", type: "speech", difficulty: 1 },
  { phrase: "Mwjangmwn?", translation: "How are you?", languageCode: "brx", type: "speech", difficulty: 1 },
  { phrase: "Gwjwithwng", translation: "Welcome", languageCode: "brx", type: "match", difficulty: 1 },
  { phrase: "Nwngni munga ma?", translation: "What is your name?", languageCode: "brx", type: "speech", difficulty: 2 },
  { phrase: "Ang nwngkhw mwnnw hwnnanw mwnnw khwina", translation: "I am happy to meet you", languageCode: "brx", type: "build", difficulty: 3 },

  // --- MIZO (LUS) ---
  { phrase: "Chibai", translation: "Hello", languageCode: "lus", type: "match", difficulty: 1 },
  { phrase: "Ka lawm e", translation: "Thank you", languageCode: "lus", type: "fill", difficulty: 2 },
  { phrase: "I dam em?", translation: "How are you?", languageCode: "lus", type: "build", difficulty: 2 },

  // --- DOGRI (DOI) ---
  { phrase: "Namaste", translation: "Hello", languageCode: "doi", type: "match", difficulty: 1 },
  { phrase: "Shukriya", translation: "Thank you", languageCode: "doi", type: "listen", difficulty: 1 },
  { phrase: "Tunda ke haal ae?", translation: "How are you?", languageCode: "doi", type: "speech", difficulty: 2 },
  { phrase: "Tusan kiyan o?", translation: "How are you?", languageCode: "doi", type: "build", difficulty: 2 },

  { phrase: "Nwng khw mwnnanwi ang mwjang mwnbai", translation: "I am happy to meet you", languageCode: "brx", type: "match", difficulty: 1 },
  { phrase: "Ang mwnnw mwnbai", translation: "I got it", languageCode: "brx", type: "fill", difficulty: 2 },

  
  { phrase: "Khawngaihin", translation: "Please", languageCode: "lus", type: "match", difficulty: 1 },
  { phrase: "Tui ka duh", translation: "I want water", languageCode: "lus", type: "speech", difficulty: 1 },
  { phrase: "Tuada naam ke ae?", translation: "What is your name?", languageCode: "doi", type: "match", difficulty: 1 },
  { phrase: "Aun thik aan", translation: "I am fine", languageCode: "doi", type: "speech", difficulty: 1 },

  // --- ADD: Level 3 speech examples for each language ---
  { phrase: "Ang nwngkhw mwnnw thangbw gwsw", translation: "I will remember this meeting", languageCode: "brx", type: "speech", difficulty: 3 },
  { phrase: "Nwngni swrwi nwngni mwnbai", translation: "Please say your full name", languageCode: "brx", type: "speech", difficulty: 3 },

  { phrase: "Khawngaihin in hriat lo", translation: "I didn't understand, please repeat", languageCode: "lus", type: "speech", difficulty: 3 },
  { phrase: "Ka nun ka hmang in ka lawm", translation: "Using my words, I will explain", languageCode: "lus", type: "speech", difficulty: 3 },

  { phrase: "Mainu tuhadi gall samajh nahi aayi", translation: "I couldn't understand what you said", languageCode: "doi", type: "speech", difficulty: 3 },
  { phrase: "Asi kal milange, thik hai?", translation: "Shall we meet tomorrow, okay?", languageCode: "doi", type: "speech", difficulty: 3 },
];

mongoose.connect(process.env.MONGO_URI)
  .then(async () => {
    console.log("📡 Connected to MongoDB Atlas..."); 
    await Word.deleteMany({}); 
    await Word.insertMany(words); 
    console.log("✅ Database Seeded Successfully with Numbers!");
    process.exit();
  })
  .catch(err => {
    console.error("❌ Seeding Error. Check your .env link!", err);
    process.exit(1);
  });