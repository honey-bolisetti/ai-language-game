
const express = require('express');
const mongoose = require('mongoose');
const cors = require('cors');
require('dotenv').config(); 

const app = express();

// --- 1. MIDDLEWARE ---
app.use(cors());
app.use(express.json());

// --- 2. DATABASE CONNECTION ---
mongoose.connect(process.env.MONGO_URI)
  .then(() => console.log("✅ Connected to MongoDB Atlas (LinguistAI)"))
  .catch(err => console.error("❌ Database connection error:", err));
// --- 3. DATA SCHEMAS ---
const wordSchema = new mongoose.Schema({
  languageCode: String, 
  phrase: String,
  translation: String,
  type: String,
  difficulty: Number 
});
const Word = mongoose.model('Word', wordSchema);

// Create a Score Schema if you haven't already in a separate file
const scoreSchema = new mongoose.Schema({
  username: String,
  score: Number,
  date: { type: Date, default: Date.now }
});
const Score = mongoose.model('Score', scoreSchema);

// --- 4. API ROUTES ---
// --- 4. API ROUTES ---

// 1. Get a Random Word for the Game
app.get('/api/random-word', async (req, res) => {
  try {
    const { lang } = req.query; 
    const query = lang ? { languageCode: { $regex: new RegExp(lang, "i") } } : {};
    
    const count = await Word.countDocuments(query);
    if (count === 0) {
      return res.status(404).json({ error: "No words found for this language" });
    }

    const random = Math.floor(Math.random() * count);
    const word = await Word.findOne(query).skip(random);
    
    res.json(word);
  } catch (err) {
    console.error("❌ Error fetching random word:", err);
    res.status(500).json({ error: "Internal Server Error" });
  }
});

// 2. Save User Scores
app.post('/api/save-score', async (req, res) => {
  const { username, score } = req.body;
  try {
    const newScore = new Score({ username, score });
    await newScore.save();
    console.log(`📊 Score Saved: User [${username}] scored [${score}]`);
    res.json({ success: true, message: "Score saved to database!" });
  } catch (err) {
    res.status(500).json({ error: "Error saving score" });
  }
});

// 3. Real Leaderboard Data (Top 30)
app.get('/api/leaderboard', async (req, res) => {
  try {
    const leaders = await Score.find().sort({ score: -1 }).limit(30);
    res.json(leaders);
  } catch (err) {
    console.error("❌ Leaderboard Error:", err);
    res.status(500).json({ message: "Error fetching leaderboard data" });
  }
});
const path = require('path');

// Serve static files from the React app
app.use(express.static(path.join(__dirname, '../frontend/frontend/build')));
// The "catch-all" handler: for any request that doesn't
// match one above, send back React's index.html file.
// This uses a Regular Expression directly to avoid path-to-regexp errors
// Use a Regular Expression to match everything
app.get(/^(?!\/api).+/, (req, res) => {
  res.sendFile(path.join(__dirname, '../frontend/frontend/build/index.html'));
});
// --- 5. START SERVER ---
const PORT = 5000;
app.listen(PORT, () => {
  console.log(`🚀 Server Engine running at http://localhost:${PORT}`);
});