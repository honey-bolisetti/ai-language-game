import React, { useState, useEffect, useCallback } from 'react';
import { useSearchParams, useNavigate } from 'react-router-dom';

const Game = ({ lang, onFinish }) => {
  const [searchParams] = useSearchParams();
  const navigate = useNavigate();
  const [questions, setQuestions] = useState([]);
  const [currentIndex, setCurrentIndex] = useState(0);
  const [options, setOptions] = useState([]);
  const [score, setScore] = useState(0);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  const gameType = searchParams.get("type") || "match";
  const level = searchParams.get("level") || "1";

  // --- 1. AUDIO OUTPUT (Text-to-Speech) ---
  const speak = (text) => {
    const msg = new SpeechSynthesisUtterance();
    msg.text = text;
    msg.lang = 'hi-IN'; // Phonetic match for Bodo/Dogri/Mizo
    window.speechSynthesis.speak(msg);
  };

  // --- 2. SPEECH INPUT (Recognition) ---
  const startListening = () => {
    const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
    if (!SpeechRecognition) return alert("Browser not supported.");

    const recognition = new SpeechRecognition();
    recognition.lang = 'hi-IN'; 
    recognition.start();

    recognition.onresult = (event) => {
      const transcript = event.results[0][0].transcript.toLowerCase();
      const targetPhrase = questions[currentIndex].phrase.toLowerCase();
      
      // If the AI hears the correct phrase
      if (transcript.includes(targetPhrase)) {
        handleAnswer(questions[currentIndex].translation);
      } else {
        alert(`AI Heard: "${transcript}"\nExpected: "${targetPhrase}"`);
      }
    };
  };

  const generateChoices = useCallback((currentQuestion, allQuestions) => {
    const correct = currentQuestion.translation;
    const distractors = allQuestions
      .filter(q => q.translation !== correct)
      .map(q => q.translation)
      .sort(() => 0.5 - Math.random())
      .slice(0, 3);
    setOptions([...distractors, correct].sort(() => 0.5 - Math.random()));
  }, []);

  useEffect(() => {
    setLoading(true);
    const url = `http://localhost:5000/api/get-words?lang=${lang}&type=${gameType}&level=${level}`;
    console.log('🔎 Fetching words from backend:', { url, lang, gameType, level });
    fetch(url)
      .then(res => res.json())
      .then(data => {
        console.log('📥 Received words:', Array.isArray(data) ? data.length : 'not-array', data && data.slice ? data.slice(0,3) : data);
        if (Array.isArray(data) && data.length > 0) {
          setQuestions(data);
          generateChoices(data[0], data);
        } else {
          setError("No questions found.");
        }
        setLoading(false);
      })
      .catch((err) => {
        console.error('❌ Fetch error:', err);
        setError("Connection failed.");
        setLoading(false);
      });
  }, [lang, gameType, level, generateChoices]);

  const handleAnswer = (selected) => {
    const isCorrect = selected === questions[currentIndex].translation;
    if (isCorrect) setScore(prev => prev + 10);
    
    if (currentIndex < questions.length - 1) {
      const nextIndex = currentIndex + 1;
      setCurrentIndex(nextIndex);
      generateChoices(questions[nextIndex], questions);
    } else {
      onFinish?.(isCorrect ? score + 10 : score);
    }
  };

  if (loading) return <div>⏳ Loading...</div>;
  if (error) return <div>⚠️ {error}</div>;

  return (
    <div style={{ textAlign: 'center', padding: '20px' }}>
      <div style={{ background: 'white', padding: '30px', borderRadius: '15px', boxShadow: '0 4px 10px rgba(0,0,0,0.1)' }}>
        
        {/* Added the 🔊 Audio button next to the phrase */}
        <h1 style={{ fontSize: '3rem', marginBottom: '10px' }}>
          {questions[currentIndex]?.phrase}
          <button 
            onClick={() => speak(questions[currentIndex]?.phrase)} 
            style={{ fontSize: '24px', marginLeft: '15px', cursor: 'pointer', border: 'none', background: 'none' }}
          >
            🔊
          </button>
        </h1>
        
        <p style={{color: '#666', marginBottom: '30px'}}>Difficulty Level: {level}</p>

        {gameType === 'speech' ? (
          <button onClick={startListening} style={{ fontSize: '50px', cursor: 'pointer', border: 'none', background: 'none' }}>
            🎙️ <p style={{fontSize: '14px'}}>Click to Speak</p>
          </button>
        ) : (
          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '10px' }}>
            {options.map((opt, i) => (
              <button 
                key={i} 
                onClick={() => handleAnswer(opt)} 
                style={{ padding: '15px', borderRadius: '8px', cursor: 'pointer', border: '1px solid #ddd' }}
              >
                {opt}
              </button>
            ))}
          </div>
        )}
      </div>
    </div>
  );
};

export default Game;