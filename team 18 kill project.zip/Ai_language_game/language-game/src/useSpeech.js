import { useState, useEffect, useCallback } from 'react';

const useSpeech = () => {
  const [transcript, setTranscript] = useState('');
  const [isListening, setIsListening] = useState(false);

  // Check for browser support
  const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
  const recognition = SpeechRecognition ? new SpeechRecognition() : null;

  if (recognition) {
    recognition.continuous = true;
    recognition.interimResults = true;
    recognition.lang = 'en-US'; // You can change this based on the language being learned
  }

  const startListening = useCallback(() => {
    if (!recognition) return alert("Browser does not support speech recognition.");
    setTranscript('');
    setIsListening(true);
    recognition.start();
  }, [recognition]);

  const stopListening = useCallback(() => {
    setIsListening(false);
    recognition && recognition.stop();
  }, [recognition]);

  useEffect(() => {
    if (!recognition) return;

    recognition.onresult = (event) => {
      const current = event.resultIndex;
      const text = event.results[current][0].transcript;
      setTranscript(text);
    };

    recognition.onerror = (event) => {
      console.error("Speech error:", event.error);
      stopListening();
    };
  }, [recognition, stopListening]);

  return { transcript, isListening, startListening, stopListening };
};

export default useSpeech;