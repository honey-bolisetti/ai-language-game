export const languageQuestions = [
  {
    id: 1,
    phrase: "Hola, ¿cómo estás?",
    translation: "Hello, how are you",
    language: "Spanish",
    difficulty: "Beginner"
  },
  {
    id: 2,
    phrase: "Bonjour tout le monde",
    translation: "Hello everyone",
    language: "French",
    difficulty: "Beginner"
  },
  {
    id: 3,
    phrase: "Ich liebe Programmieren",
    translation: "I love programming",
    language: "German",
    difficulty: "Intermediate"
  },
  {
    id: 4,
    phrase: "La mela è rossa",
    translation: "The apple is red",
    language: "Italian",
    difficulty: "Beginner"
  }
];