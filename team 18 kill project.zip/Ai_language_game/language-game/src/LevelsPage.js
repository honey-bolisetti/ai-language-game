import React from 'react';
import { useNavigate, useSearchParams } from 'react-router-dom';

const LevelsPage = () => {
  const navigate = useNavigate();
  const [searchParams] = useSearchParams();
  const lang = searchParams.get("lang");
  const type = searchParams.get("type");

  const selectLevel = (lvl) => {
    // This sends the user to the Game with the correct Algorithm filters
    navigate(`/game?lang=${lang}&type=${type}&level=${lvl}`);
  };

  return (
    <div style={{ padding: '20px', textAlign: 'center' }}>
      <h2>Select Difficulty</h2>
      <div style={{ display: 'flex', flexDirection: 'column', gap: '10px', alignItems: 'center' }}>
        <button onClick={() => selectLevel(0)} className="btn-practice">🔄 Practice Mode</button>
        <button onClick={() => selectLevel(1)} className="btn-lvl">🟢 Level 1: Beginner</button>
        <button onClick={() => selectLevel(2)} className="btn-lvl">🟡 Level 2: Intermediate</button>
        <button onClick={() => selectLevel(3)} className="btn-lvl">🔴 Level 3: Expert</button>
      </div>
    </div>
  );
};

export default LevelsPage;