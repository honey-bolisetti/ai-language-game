import React, { useState, useEffect } from 'react';
import { BrowserRouter as Router, Routes, Route, useNavigate } from 'react-router-dom';
import Game from './Game';

// Debug helper so you can tell which frontend bundle is running in the browser
console.log('🧭 language-game App loaded (src/App.js)');

// --- SHARED STYLES ---
const pageStyle = { textAlign: 'center', padding: '20px', fontFamily: 'Arial', backgroundColor: '#f4f7f6', minHeight: '100vh', display: 'flex', flexDirection: 'column', alignItems: 'center' };
const btnStyle = { padding: '15px 30px', margin: '10px', cursor: 'pointer', borderRadius: '8px', border: 'none', background: '#3498db', color: 'white', fontWeight: 'bold', width: '280px' };
const cardStyle = { borderRadius: '15px', padding: '20px', width: '90%', maxWidth: '400px', background: 'white', boxShadow: '0 4px 10px rgba(0,0,0,0.1)', marginTop: '20px' };
const backBtnStyle = { background: 'none', border: 'none', color: '#e74c3c', cursor: 'pointer', textDecoration: 'underline', marginTop: '20px', fontWeight: 'bold' };

// --- PAGE 1: LOGIN ---
const LoginPage = () => {
  const navigate = useNavigate();
  const [name, setName] = useState("");
  return (
    <div style={pageStyle}>
      <h1>🔐 Welcome to Game</h1>
      <div style={cardStyle}>
        <input 
          type="text" 
          placeholder="Username" 
          value={name}
          style={{padding: '10px', margin: '10px', width: '80%'}} 
          onChange={(e) => setName(e.target.value)} 
        /><br/>
        <button 
          onClick={() => {
            if (name.trim() === "") return alert("Please enter a name!");
            localStorage.setItem('username', name); 
            navigate('/select-language');
          }} 
          style={btnStyle}
        >
          Enter Game
        </button>
      </div>
    </div>
  );
};

// --- PAGE 2: LANGUAGE SELECTION ---
const LanguageSelection = ({ setLang }) => {
  const navigate = useNavigate();
  const select = (code) => { setLang(code); navigate('/levels'); };
  return (
    <div style={pageStyle}>
      <h1>🌍 Select Your Language</h1>
      <button onClick={() => select('brx')} style={{...btnStyle, background: '#2ecc71'}}>Bodo (BRX)</button>
      <button onClick={() => select('lus')} style={{...btnStyle, background: '#e67e22'}}>Mizo (LUS)</button>
      <button onClick={() => select('doi')} style={{...btnStyle, background: '#9b59b6'}}>Dogri (DOI)</button>
    </div>
  );
};

// --- PAGE 3: LEVELS & MODULES ---
const LevelsPage = ({ lang }) => {
  const navigate = useNavigate();
  const [selectedMod, setSelectedMod] = useState(null);

  const modules = [
    { name: "🔤 Word Match", type: "match" },
    { name: "🎤 Pronunciation", type: "speech" },
    { name: "📝 Fill in the Blanks", type: "fill" },
    { name: "🧩 Sentence Builder", type: "build" },
    { name: "🎧 Listening Quiz", type: "listen" }
  ];

  if (!selectedMod) {
    return (
      <div style={pageStyle}>
        <h1>🎮 Select Module ({lang.toUpperCase()})</h1>
        {modules.map((m, i) => (
          <button key={i} onClick={() => setSelectedMod(m.type)} style={{...btnStyle, background: '#9b59b6'}}>{m.name}</button>
        ))}
        <button onClick={() => navigate('/leaderboard')} style={{...btnStyle, background: '#f1c40f'}}>🏆 Leaderboard</button>
        <button onClick={() => navigate('/select-language')} style={backBtnStyle}>🔙 Change Language</button>
      </div>
    );
  }

  return (
    <div style={pageStyle}>
      <h1>🏆 Select Difficulty</h1>
      <button onClick={() => navigate(`/quiz?type=${selectedMod}&level=0`)} style={{...btnStyle, background: '#7f8c8d'}}>🔄 Practice Mode</button>
      <button onClick={() => navigate(`/quiz?type=${selectedMod}&level=1`)} style={{...btnStyle, background: '#27ae60'}}>🟢 Level 1</button>
      <button onClick={() => navigate(`/quiz?type=${selectedMod}&level=2`)} style={{...btnStyle, background: '#f39c12'}}>🟡 Level 2</button>
      <button onClick={() => navigate(`/quiz?type=${selectedMod}&level=3`)} style={{...btnStyle, background: '#c0392b'}}>🔴 Level 3</button>
      <button onClick={() => setSelectedMod(null)} style={backBtnStyle}>🔙 Back to Modules</button>
    </div>
  );
};

// --- PAGE 5: LEADERBOARD ---
const LeaderboardPage = () => {
  const [leaders, setLeaders] = useState([]);
  const navigate = useNavigate();

  useEffect(() => {
    fetch('http://localhost:5000/api/leaderboard')
      .then(res => res.json())
      .then(data => setLeaders(Array.isArray(data) ? data : []))
      .catch(err => console.error("Leaderboard error:", err));
  }, []);

  return (
    <div style={pageStyle}>
      <h1>🏆 Leaderboard</h1>
      <div style={cardStyle}>
        <table style={{ width: '100%', borderCollapse: 'collapse' }}>
          <thead>
            <tr style={{ borderBottom: '2px solid #3498db' }}>
              <th>Rank</th><th>Player</th><th>Score</th>
            </tr>
          </thead>
          <tbody>
            {leaders.map((p, i) => (
              <tr key={i} style={{ borderBottom: '1px solid #eee' }}>
                <td>{i + 1}</td><td>{p.username}</td><td>{p.totalScore || p.score}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
      <button onClick={() => navigate('/levels')} style={btnStyle}>Back to Menu</button>
    </div>
  );
};

// --- MAIN APP COMPONENT ---
export default function App() {
  const [lang, setLang] = useState('brx');

  return (
    <Router>
      <Routes>
        <Route path="/" element={<LoginPage />} />
        <Route path="/select-language" element={<LanguageSelection setLang={setLang} />} />
        <Route path="/levels" element={<LevelsPage lang={lang} />} />
        <Route path="/leaderboard" element={<LeaderboardPage />} />
        <Route 
          path="/quiz" 
          element={
            <Game 
              lang={lang} 
              onFinish={async (finalScore) => {
                const savedName = localStorage.getItem('username') || "Anonymous";
                try {
                  await fetch('http://localhost:5000/api/save-score', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({ username: savedName, score: finalScore })
                  });
                  window.location.href = '/leaderboard';
                } catch (err) {
                  console.error("Score save error:", err);
                  window.location.href = '/leaderboard';
                }
              }} 
            />
          } 
        />
      </Routes>
    </Router>
  );
}