import React from 'react';

const Result = ({ score, totalQuestions, onRestart }) => {
  // Simple AI logic to determine the message
  const getMessage = () => {
    if (score === totalQuestions) return "Perfect! You're a Natural! 🌟";
    if (score > totalQuestions / 2) return "Great Job! Keep Practicing! 📚";
    return "Don't give up! Every mistake is a lesson. 💪";
  };

  return (
    <div className="result-container">
      <div className="result-card">
        <h1>Lesson Complete!</h1>
        <div className="score-circle">
          <span className="score-number">{score}</span>
          <span className="total-number">/ {totalQuestions}</span>
        </div>
        <p className="ai-feedback">{getMessage()}</p>
        
        <button className="restart-btn" onClick={onRestart}>
          Try Again
        </button>
      </div>
    </div>
  );
};

export default Result;