import React from 'react';

const Home = ({ onStart }) => {
  return (
    <div className="App"> {/* This applies the moving gradient background */}
      <div className="game-card"> {/* This creates the glowing glass box */}
        <h1 style={{ fontSize: '3rem', marginBottom: '10px' }}>🌍 LinguistAI</h1>
        <p style={{ fontSize: '1.2rem', opacity: '0.9', marginBottom: '30px' }}>
          Master a new language with your personal AI tutor.
        </p>
        <button onClick={onStart}>Start Learning Now</button>
      </div>
    </div>
  );
};

export default Home;