const useTextToSpeech = () => {
  const speak = (text, language) => {
    const utterance = new SpeechSynthesisUtterance(text);
    // This helps the AI pick the right accent
    if (language === 'Spanish') utterance.lang = 'es-ES';
    else if (language === 'French') utterance.lang = 'fr-FR';
    else if (language === 'German') utterance.lang = 'de-DE';
    else if (language === 'Italian') utterance.lang = 'it-IT';
    
    window.speechSynthesis.speak(utterance);
  };

  return { speak };
};

export default useTextToSpeech;